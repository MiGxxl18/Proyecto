package Interfaces;

/**
 * Interface para guardar variables globales
 */
public interface Constants {
    String SiteUrl = "https://demoqa.com/";

    String SiteTitle = "ToolsQA";

    String bodyId = "app";

}