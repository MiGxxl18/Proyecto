package Tests;

public interface Page {
    public final String URL_INDEX = "https://demoqa.com/";
    public String getUrl();
    //System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\OneDrive\\Escritorio\\PruebasAutomatizadas\\src\\main\\resources\\drivers\\chromedriver.exe");

}
