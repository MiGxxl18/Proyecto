package Tests;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import  org.openqa.selenium.chrome.ChromeDriver;

import javax.swing.*;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class ProgressBar {
    public  static  void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\OneDrive\\Escritorio\\PruebasAutomatizadas\\src\\main\\resources\\drivers\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        //abrir pagina web
        driver.get("https://demoqa.com/progress-bar");

        //max pagina web
        driver.manage().window().maximize();

        //se usa esta herramienta por que selenium no proporciana ningun metodo para mover hacia arriba o hacia abajo

        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/button")).click();

        //driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);

        //driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/button")).click();


    }


}
