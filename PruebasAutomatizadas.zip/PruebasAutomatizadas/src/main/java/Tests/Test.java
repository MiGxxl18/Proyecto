package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.sql.Driver;
import java.util.concurrent.TimeUnit;

public class Test {
    public  static  void main(String[] args){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\LENOVO\\OneDrive\\Escritorio\\PruebasAutomatizadas\\src\\main\\resources\\drivers\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        //abrir pagina web
        driver.get("https://demoqa.com/tabs");

        //max pagina web
        driver.manage().window().maximize();

        //driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div[2]/div/div[4]")).click();


        //se usa esta herramienta por que selenium no proporciana ningun metodo para mover hacia arriba o hacia abajo

        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/nav/a[2]")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/nav/a[1]")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/nav/a[3]")).click();

        driver.findElement(By.xpath("/html/body/div[2]/div/div/div[2]/div[2]/div[2]/nav/a[4]")).click();

        //hacer click en la widgets


    }


}